build image

$ docker build -t devopstest:1 .

Note: This task will give error
