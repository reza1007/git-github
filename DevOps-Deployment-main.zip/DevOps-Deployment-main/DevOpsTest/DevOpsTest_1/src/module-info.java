/**
 * 
 */
/**
 * @author Asus
 *
 */
module DevOpsTest {
	requires java.logging;
}